#!/bin/sh

docker stop builder
docker rm builder

