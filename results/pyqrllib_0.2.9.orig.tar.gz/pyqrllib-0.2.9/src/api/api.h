// Distributed under the MIT software license, see the accompanying
// file LICENSE or http://www.opensource.org/licenses/mit-license.php.

#ifndef API_API_H
#define API_API_H

#endif //API_API_H
