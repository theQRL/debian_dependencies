#include <array>
#include <string>

extern const std::array<std::string, 4096> wordlist;

